package com.example.joelle.liu_tutoring;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class studentBookActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_book);
    }
}
